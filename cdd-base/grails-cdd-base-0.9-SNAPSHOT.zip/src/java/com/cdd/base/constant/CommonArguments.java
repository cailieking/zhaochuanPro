package com.cdd.base.constant;
public interface CommonArguments {
	final static String NEWSTEMP = "news.ftl" ;
	final static String LOCAL_DEVELOPMENT = "localhost" ;
	final static String PROGRAM_DEVELOPMENT = "120.25.103.111" ;
	final static String PRODUCT_DEVELOPMENT = "www.zhao-chuan.com" ;
}
