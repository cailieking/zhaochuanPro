package com.cdd.base.constant;

public interface DatabaseConstant {
	String DEFAULT_MODULE = "default";
	String ORDER_BY_DESC = "desc";
	String ORDER_BY_ASC = "asc";

}
