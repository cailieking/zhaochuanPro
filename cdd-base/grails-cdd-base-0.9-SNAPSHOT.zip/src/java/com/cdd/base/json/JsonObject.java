package com.cdd.base.json;

import java.io.Serializable;

public interface JsonObject extends Serializable {

}
